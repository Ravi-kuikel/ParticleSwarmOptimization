import math as ma
import random  as rd
import Dag as yo


class particleswarm:
    def __init__(self, n, m):  # Step 1
        self.w = 0.7968  # inertia factor
        self.c1 = 1.4962  # Acceleration factor
        self.c2 = 1.4962  # Accceleration factor
        self.n = n
        self.m = m
        self.position = []
        self.velocity = []
        # Inializing velocity and position
        for i in range(self.n):
            ar = []
            for j in range(self.m):
                ar.append(rd.randint(1, 3))
            self.position.append(ar)
        for i in range(self.n):
            ma = []
            for j in range(self.m):
                ma.append((self.position[i][j] * 0.1))
            self.velocity.append(ma)
        # currentposition at 0 iteration cp=position+velocity
        for i in range(n):
            for j in range(m):
                self.position[i][j] = round(self.position[i][j] + self.velocity[i][j]) % 3 + 1
        self.xbest=[]
        for i in range(self.n):
            arr=[]
            for j in range(self.m):
                arr.append(self.position[i][j])
            self.xbest.append(arr)

    def algo(self):
        FTb = self.fitness()  # Step 2
        gbest = []
        value = min(FTb)
        index=FTb.index(value)
        for i in self.position[index]:
            gbest.append(i)

        iter = int(input("No of iteration"))
        n = iter

        while iter > 0:
            self.updatevelocity(gbest)
            self.updateposition()
            FTc = self.fitness()

            for i in range(self.n):  # Updating Global best and xbest
                if FTb[i] > FTc[i]:
                    self.xbest[i] = self.position[i]
                    # Update xbest
                    FTb[i] = FTc[i]  # Update Best Fitness
                if FTc[i] < value:
                    value = FTc[i]
                    ind=FTc.index(value)
                    for j in range(len(self.position[ind])):
                        gbest[j]=self.position[ind][j]

            print("After ",n-iter,"th"," Iterations Best Makespan=",value,"And Position corresponding to it is=",gbest)
            iter -= 1

    def fitness(self):
        ft = []
        obj = yo.DAG()
        for i in self.position:
            ft.append(obj.makespan(i))
        return ft

    def updatevelocity(self, gbest):
        for i in range(self.n):
            for j in range(self.m):
                self.velocity[i][j] = (self.w * self.velocity[i][j]) + (
                            (self.c1 * rd.random()) * (self.xbest[i][j] - self.position[i][j])) + (
                                                  (self.c2 * rd.random()) * (gbest[j] - self.position[i][j]))

    def updateposition(self):
        for i in range(self.n):
            for j in range(self.m):
                self.position[i][j] = round(self.position[i][j] + self.velocity[i][j]) % 3 + 1


obj = particleswarm(5, 10)
obj.algo()
