class DAG:
    def __init__(self):

        self.dag = [[],  # t1
                    [(1, 18)],  # t2
                    [(1, 12)],  # t3
                    [(1, 9)],  # t4
                    [(1, 11)],  # t5
                    [(1, 14)],  # t6
                    [(3, 23)],  # t7
                    [(4, 27), (2, 19), (6, 15)],  # t8
                    [(4, 23), (5, 13), (2, 16)],  # t9
                    [(7, 17), (8, 11), (9,
                                        13)]]  # t10                                     # This matrix represents parent child relationship and communication time

        self.eTime = [
            [14, 16, 9],
            [13, 19, 18],
            [11, 13, 19],
            [13, 8, 17],
            [12, 13, 10],
            [13, 16, 9],
            [7, 15, 11],
            [5, 11, 14],
            [18, 12, 20],
            [21, 7, 16]
        ]  # Execution time of a task in 3 different vms

        self.seq = [1, 2, 3, 5, 4, 6, 7, 9, 8, 10]  # Order in which task is to be executed

    def makespan(self, vmassign):
        vms = []  # This list contains starttime and finishtime for each vm
        for i in range(len(self.eTime[0])):
            vms.append([-1, -1])
        tst = []  # This list contains starttime,finishtime,vmassigned for each task
        for i in range(len(vmassign)):
            tst.append([-1, -1, vmassign[i]])

        count = 0

        while count < len(self.seq):
            task = self.seq[count]
            parents = self.dag[task - 1]
            vm = vmassign[task - 1]
            if parents == None:
                if vms[vm - 1] != -1:
                    start = vms[vm - 1][1]
                    finish = start + self.eTime[task - 1][vm - 1]
                else:
                    start = 0
                    finish = finish = start + self.eTime[task - 1][vm - 1]
            else:

                mx = 0
                for i in parents:
                    node, ct = i
                    if mx < tst[node - 1][1] + ct and vm != tst[node - 1][2]:
                        mx = tst[node - 1][1] + ct
                    elif mx < tst[node - 1][1]:
                        mx = tst[node - 1][1]
                    else:
                        pass
                if mx>vms[vm-1][1]:
                    start=mx
                else:
                    start=vms[vm-1][1]
                finish=start+self.eTime[task-1][vm-1]

            vms[vm - 1][0] = start
            vms[vm - 1][1] = finish
            tst[task - 1][0], tst[task - 1][1] = start, finish
            count += 1
        return finish


obj = DAG()
sa = [[3, 2, 2, 2, 2, 3, 2, 2, 2, 2],[3, 2, 1, 2, 3, 3, 1, 2, 2, 2]]


for i in sa:
    print(obj.makespan(i))
